"""
Camada de persistência Postgres: staging (raw JSONB) + mart (tabelas modeladas).

Estratégia:
  - UPSERT via INSERT ... ON CONFLICT DO UPDATE (idempotente)
  - JSONB na staging preserva o payload original
  - Mart extrai os campos mais usados em BI
  - Tokens OAuth também ficam no banco (linha única id=1)
"""
from __future__ import annotations

import json
import logging
from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Any, Dict, Iterable, Optional

import psycopg2
import psycopg2.extras

from contaazul_auth import TokenSet

logger = logging.getLogger(__name__)


class PostgresStore:
    def __init__(self, dsn: Dict[str, Any]):
        self.dsn = dsn

    @contextmanager
    def conn(self):
        c = psycopg2.connect(**self.dsn)
        try:
            yield c
            c.commit()
        except Exception:
            c.rollback()
            raise
        finally:
            c.close()

    # ---------------------------------------------------------------- tokens
    def load_tokens(self) -> Optional[TokenSet]:
        with self.conn() as c, c.cursor() as cur:
            cur.execute(
                "SELECT access_token, refresh_token, expires_at "
                "FROM staging_contaazul.oauth_tokens WHERE id = 1"
            )
            row = cur.fetchone()
            if not row:
                return None
            return TokenSet(
                access_token=row[0],
                refresh_token=row[1],
                expires_at=row[2] if row[2].tzinfo else row[2].replace(tzinfo=timezone.utc),
            )

    def save_tokens(self, tokens: TokenSet) -> None:
        with self.conn() as c, c.cursor() as cur:
            cur.execute(
                """
                INSERT INTO staging_contaazul.oauth_tokens
                    (id, access_token, refresh_token, expires_at, updated_at)
                VALUES (1, %s, %s, %s, NOW())
                ON CONFLICT (id) DO UPDATE SET
                    access_token  = EXCLUDED.access_token,
                    refresh_token = EXCLUDED.refresh_token,
                    expires_at    = EXCLUDED.expires_at,
                    updated_at    = NOW()
                """,
                (tokens.access_token, tokens.refresh_token, tokens.expires_at),
            )

    # ---------------------------------------------------------- sync_control
    def log_sync(self, endpoint: str, status: str, records: int, error: str = "") -> None:
        with self.conn() as c, c.cursor() as cur:
            cur.execute(
                """
                INSERT INTO staging_contaazul.sync_control
                    (endpoint, last_sync_at, last_success_at, last_status, last_error, records_last_run)
                VALUES (%s, NOW(), CASE WHEN %s='OK' THEN NOW() END, %s, %s, %s)
                ON CONFLICT (endpoint) DO UPDATE SET
                    last_sync_at     = NOW(),
                    last_success_at  = CASE WHEN EXCLUDED.last_status='OK'
                                            THEN NOW()
                                            ELSE staging_contaazul.sync_control.last_success_at END,
                    last_status      = EXCLUDED.last_status,
                    last_error       = EXCLUDED.last_error,
                    records_last_run = EXCLUDED.records_last_run
                """,
                (endpoint, status, status, error[:1000], records),
            )

    # ---------------------------------------------------------------- staging
    def upsert_raw(self, table: str, records: Iterable[Dict[str, Any]],
                   extra_cols: Optional[Dict[str, Any]] = None) -> int:
        """
        UPSERT genérico em staging. Extrai 'id' do registro, grava payload como JSONB.
        extra_cols permite gravar colunas adicionais (ex: id_evento, tipo_evento).
        """
        extra_cols = extra_cols or {}
        rows = []
        for rec in records:
            rid = rec.get("id")
            if not rid:
                continue
            row = {"id": rid, "payload": json.dumps(rec, ensure_ascii=False, default=str)}
            row.update(extra_cols)
            rows.append(row)

        if not rows:
            return 0

        cols = list(rows[0].keys())
        cols_sql = ", ".join(cols)
        placeholders = ", ".join(["%s"] * len(cols))
        updates = ", ".join([f"{c}=EXCLUDED.{c}" for c in cols if c != "id"])
        sql = (
            f"INSERT INTO staging_contaazul.{table} ({cols_sql}, loaded_at) "
            f"VALUES ({placeholders}, NOW()) "
            f"ON CONFLICT (id) DO UPDATE SET {updates}, loaded_at = NOW()"
        )

        values = [tuple(r[c] for c in cols) for r in rows]
        with self.conn() as c, c.cursor() as cur:
            psycopg2.extras.execute_batch(cur, sql, values, page_size=200)
        return len(rows)

    # ---------------------------------------------------------------- marts
    def refresh_dim_categoria(self) -> int:
        sql = """
        INSERT INTO mart_contaazul.dim_categoria
            (id_categoria, codigo, nome, tipo, id_categoria_pai, ativo, atualizado_em)
        SELECT
            id,
            payload->>'codigo',
            payload->>'nome',
            payload->>'tipo',
            NULLIF(payload->>'id_categoria_pai','')::uuid,
            COALESCE((payload->>'ativo')::boolean, TRUE),
            NOW()
        FROM staging_contaazul.raw_categorias
        ON CONFLICT (id_categoria) DO UPDATE SET
            codigo           = EXCLUDED.codigo,
            nome             = EXCLUDED.nome,
            tipo             = EXCLUDED.tipo,
            id_categoria_pai = EXCLUDED.id_categoria_pai,
            ativo            = EXCLUDED.ativo,
            atualizado_em    = NOW();
        """
        return self._exec_count(sql)

    def refresh_dim_centro_custo(self) -> int:
        sql = """
        INSERT INTO mart_contaazul.dim_centro_custo
            (id_centro_custo, codigo, nome, ativo, atualizado_em)
        SELECT
            id,
            payload->>'codigo',
            payload->>'nome',
            COALESCE((payload->>'ativo')::boolean, TRUE),
            NOW()
        FROM staging_contaazul.raw_centros_custo
        ON CONFLICT (id_centro_custo) DO UPDATE SET
            codigo = EXCLUDED.codigo,
            nome   = EXCLUDED.nome,
            ativo  = EXCLUDED.ativo,
            atualizado_em = NOW();
        """
        return self._exec_count(sql)

    def refresh_dim_conta_financeira(self) -> int:
        sql = """
        INSERT INTO mart_contaazul.dim_conta_financeira
            (id_conta, nome, tipo, ativo, atualizado_em)
        SELECT
            id,
            payload->>'nome',
            payload->>'tipo',
            COALESCE((payload->>'ativo')::boolean, TRUE),
            NOW()
        FROM staging_contaazul.raw_contas_financeiras
        ON CONFLICT (id_conta) DO UPDATE SET
            nome  = EXCLUDED.nome,
            tipo  = EXCLUDED.tipo,
            ativo = EXCLUDED.ativo,
            atualizado_em = NOW();
        """
        return self._exec_count(sql)

    def refresh_fato_parcela(self) -> int:
        """
        Extrai campos do JSONB de raw_parcelas para a fato.
        Os nomes dos campos seguem o payload documentado em:
        https://developers.contaazul.com/docs/financial-apis-openapi/v1
        """
        sql = """
        INSERT INTO mart_contaazul.fato_parcela (
            id_parcela, id_evento, tipo_evento, indice_parcela, status,
            data_vencimento, data_pagamento_previsto, data_competencia,
            valor_original, valor_pago, valor_nao_pago,
            id_conta_financeira, id_categoria, id_centro_custo, id_contato,
            descricao, forma_pagamento, atualizado_em
        )
        SELECT
            p.id,
            p.id_evento,
            p.tipo_evento,
            NULLIF(p.payload->>'indice','')::int,
            p.payload->>'status',
            NULLIF(p.payload->>'data_vencimento','')::date,
            NULLIF(p.payload->>'data_pagamento_previsto','')::date,
            NULLIF(p.payload#>>'{evento,data_competencia}','')::date,
            NULLIF(p.payload#>>'{detalhe_valor,valor}','')::numeric,
            NULLIF(p.payload->>'valor_pago','')::numeric,
            NULLIF(p.payload->>'nao_pago','')::numeric,
            NULLIF(p.payload#>>'{conta_financeira,id}','')::uuid,
            NULLIF(p.payload#>>'{evento,categoria,id}','')::uuid,
            NULLIF(p.payload#>>'{evento,centro_custo,id}','')::uuid,
            NULLIF(p.payload#>>'{evento,contato,id}','')::uuid,
            p.payload->>'descricao',
            p.payload->>'forma_pagamento',
            NOW()
        FROM staging_contaazul.raw_parcelas p
        ON CONFLICT (id_parcela) DO UPDATE SET
            status                  = EXCLUDED.status,
            data_vencimento         = EXCLUDED.data_vencimento,
            data_pagamento_previsto = EXCLUDED.data_pagamento_previsto,
            data_competencia        = EXCLUDED.data_competencia,
            valor_original          = EXCLUDED.valor_original,
            valor_pago              = EXCLUDED.valor_pago,
            valor_nao_pago          = EXCLUDED.valor_nao_pago,
            id_conta_financeira     = EXCLUDED.id_conta_financeira,
            id_categoria            = EXCLUDED.id_categoria,
            id_centro_custo         = EXCLUDED.id_centro_custo,
            id_contato              = EXCLUDED.id_contato,
            descricao               = EXCLUDED.descricao,
            forma_pagamento         = EXCLUDED.forma_pagamento,
            atualizado_em           = NOW();
        """
        return self._exec_count(sql)

    def refresh_fato_venda(self) -> int:
        sql = """
        INSERT INTO mart_contaazul.fato_venda (
            id_venda, numero_venda, data_venda, status,
            id_cliente, valor_total, valor_desconto, observacao, atualizado_em
        )
        SELECT
            id,
            payload->>'numero',
            NULLIF(payload->>'data_venda','')::date,
            payload->>'status',
            NULLIF(payload#>>'{cliente,id}','')::uuid,
            NULLIF(payload->>'valor_total','')::numeric,
            NULLIF(payload->>'valor_desconto','')::numeric,
            payload->>'observacao',
            NOW()
        FROM staging_contaazul.raw_vendas
        ON CONFLICT (id_venda) DO UPDATE SET
            numero_venda   = EXCLUDED.numero_venda,
            data_venda     = EXCLUDED.data_venda,
            status         = EXCLUDED.status,
            id_cliente     = EXCLUDED.id_cliente,
            valor_total    = EXCLUDED.valor_total,
            valor_desconto = EXCLUDED.valor_desconto,
            observacao     = EXCLUDED.observacao,
            atualizado_em  = NOW();
        """
        return self._exec_count(sql)

    def _exec_count(self, sql: str) -> int:
        with self.conn() as c, c.cursor() as cur:
            cur.execute(sql)
            return cur.rowcount
