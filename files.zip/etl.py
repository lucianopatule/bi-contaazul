"""
ETL ContaAzul → PostgreSQL

Uso:
    # 1) Instalar dependências
    pip install -r requirements.txt

    # 2) Aplicar schema
    psql -h $PG_HOST -U $PG_USER -d $PG_DATABASE -f schema.sql

    # 3) Copiar .env.example para .env e preencher credenciais
    cp .env.example .env

    # 4) Primeira execução (vai abrir navegador para autorização)
    python etl.py --bootstrap

    # 5) Execuções periódicas (cron/agendador)
    python etl.py

    # Forçar reprocessamento completo (janela ampla):
    python etl.py --full

Endpoints cobertos (api-v2.contaazul.com/v1):
    /categorias                                     → dim_categoria
    /centro-de-custo                                → dim_centro_custo
    /conta-financeira                               → dim_conta_financeira
    /financeiro/eventos-financeiros/contas-a-pagar/buscar    → fato_parcela
    /financeiro/eventos-financeiros/contas-a-receber/buscar  → fato_parcela
    /v1/venda (endpoint de vendas — ajuste conforme plano contratado)
"""
from __future__ import annotations

import argparse
import logging
import os
import sys
from datetime import date, datetime, timedelta, timezone
from typing import Any, Dict, Iterable

from dotenv import load_dotenv

from contaazul_auth import TokenSet, interactive_authorize
from contaazul_client import ContaAzulClient
from postgres_store import PostgresStore

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-7s | %(name)s | %(message)s",
)
logger = logging.getLogger("etl")


# ============================================================ configuração
def load_config() -> Dict[str, Any]:
    load_dotenv()
    missing = [
        k for k in [
            "CONTAAZUL_CLIENT_ID", "CONTAAZUL_CLIENT_SECRET", "CONTAAZUL_REDIRECT_URI",
            "PG_HOST", "PG_DATABASE", "PG_USER", "PG_PASSWORD",
        ] if not os.getenv(k)
    ]
    if missing:
        raise RuntimeError(f"Variáveis ausentes no .env: {', '.join(missing)}")

    return {
        "client_id":     os.environ["CONTAAZUL_CLIENT_ID"],
        "client_secret": os.environ["CONTAAZUL_CLIENT_SECRET"],
        "redirect_uri":  os.environ["CONTAAZUL_REDIRECT_URI"],
        "pg_dsn": {
            "host":     os.environ["PG_HOST"],
            "port":     int(os.getenv("PG_PORT", "5432")),
            "dbname":   os.environ["PG_DATABASE"],
            "user":     os.environ["PG_USER"],
            "password": os.environ["PG_PASSWORD"],
        },
        "janela_dias": int(os.getenv("ETL_JANELA_DIAS", "365")),
        "page_size":   int(os.getenv("ETL_PAGE_SIZE", "100")),
    }


# ============================================================ bootstrap
def bootstrap_tokens(cfg: Dict[str, Any], store: PostgresStore) -> TokenSet:
    logger.info("Iniciando autorização interativa OAuth 2.0...")
    tokens = interactive_authorize(
        client_id=cfg["client_id"],
        client_secret=cfg["client_secret"],
        redirect_uri=cfg["redirect_uri"],
        scopes="sales",
    )
    store.save_tokens(tokens)
    logger.info("Tokens gravados em staging_contaazul.oauth_tokens.")
    return tokens


# ============================================================ ingestão
def _safe_ingest(endpoint_name: str, store: PostgresStore, fn) -> None:
    """Envolve uma ingestão em try/except e registra em sync_control."""
    try:
        count = fn()
        store.log_sync(endpoint_name, "OK", count)
        logger.info("  %-40s → %d registros", endpoint_name, count)
    except Exception as e:
        store.log_sync(endpoint_name, "ERROR", 0, error=str(e))
        logger.exception("  %-40s → FALHOU: %s", endpoint_name, e)


def ingest_categorias(client: ContaAzulClient, store: PostgresStore) -> int:
    recs = list(client.paginate("/categorias"))
    return store.upsert_raw("raw_categorias", recs)


def ingest_centros_custo(client: ContaAzulClient, store: PostgresStore) -> int:
    recs = list(client.paginate("/centro-de-custo"))
    return store.upsert_raw("raw_centros_custo", recs)


def ingest_contas_financeiras(client: ContaAzulClient, store: PostgresStore) -> int:
    recs = list(client.paginate("/conta-financeira"))
    return store.upsert_raw("raw_contas_financeiras", recs)


def _ingest_eventos_financeiros(
    client: ContaAzulClient,
    store: PostgresStore,
    tipo: str,  # "pagar" ou "receber"
    data_de: date,
    data_ate: date,
) -> int:
    """
    Ingere eventos financeiros + suas parcelas.
    Endpoint de busca: /financeiro/eventos-financeiros/contas-a-{tipo}/buscar
    """
    tipo_tabela = "raw_contas_pagar" if tipo == "pagar" else "raw_contas_receber"
    tipo_evento = "PAGAR" if tipo == "pagar" else "RECEBER"

    path_busca = f"/financeiro/eventos-financeiros/contas-a-{tipo}/buscar"
    params = {
        "data_vencimento_de":  data_de.isoformat(),
        "data_vencimento_ate": data_ate.isoformat(),
    }

    eventos = list(client.paginate(path_busca, params=params))
    n_eventos = store.upsert_raw(tipo_tabela, eventos)

    # para cada evento, baixar as parcelas
    # endpoint: /financeiro/eventos-financeiros/{id_evento}/parcelas
    total_parcelas = 0
    for ev in eventos:
        ev_id = ev.get("id")
        if not ev_id:
            continue
        try:
            parcelas = client.get(f"/financeiro/eventos-financeiros/{ev_id}/parcelas") or []
            if isinstance(parcelas, dict):
                # caso a resposta venha envelopada
                for key in ("itens", "items", "data"):
                    if key in parcelas and isinstance(parcelas[key], list):
                        parcelas = parcelas[key]
                        break
            if not isinstance(parcelas, list):
                parcelas = []
            total_parcelas += store.upsert_raw(
                "raw_parcelas",
                parcelas,
                extra_cols={"id_evento": ev_id, "tipo_evento": tipo_evento},
            )
        except Exception as e:
            logger.warning("    parcelas do evento %s falharam: %s", ev_id, e)

    logger.info("    %s: %d eventos, %d parcelas", tipo_evento, n_eventos, total_parcelas)
    return n_eventos + total_parcelas


def ingest_contas_pagar(client, store, data_de, data_ate):
    return _ingest_eventos_financeiros(client, store, "pagar", data_de, data_ate)


def ingest_contas_receber(client, store, data_de, data_ate):
    return _ingest_eventos_financeiros(client, store, "receber", data_de, data_ate)


def ingest_vendas(client: ContaAzulClient, store: PostgresStore,
                  data_de: date, data_ate: date) -> int:
    """
    Endpoint de vendas na nova API. Caso sua aplicação use o endpoint legado
    (/v1/sales), ajuste o path abaixo conforme sua documentação/plano.
    """
    params = {
        "data_inicio": data_de.isoformat(),
        "data_fim":    data_ate.isoformat(),
    }
    try:
        recs = list(client.paginate("/venda", params=params))
    except Exception:
        # fallback para path alternativo caso sua aplicação use outro endpoint
        logger.info("  /venda falhou, tentando /vendas...")
        recs = list(client.paginate("/vendas", params=params))
    return store.upsert_raw("raw_vendas", recs)


# ============================================================ main
def main():
    parser = argparse.ArgumentParser(description="ETL ContaAzul → Postgres")
    parser.add_argument("--bootstrap", action="store_true",
                        help="Executa autorização OAuth 2.0 interativa e grava tokens.")
    parser.add_argument("--full", action="store_true",
                        help="Força carga completa usando ETL_JANELA_DIAS.")
    parser.add_argument("--dias", type=int, default=None,
                        help="Sobrescreve janela em dias para esta execução.")
    args = parser.parse_args()

    cfg = load_config()
    store = PostgresStore(cfg["pg_dsn"])

    # -------- tokens
    tokens = store.load_tokens()
    if args.bootstrap or tokens is None:
        if tokens is None:
            logger.info("Nenhum token encontrado no banco. Iniciando bootstrap...")
        tokens = bootstrap_tokens(cfg, store)

    client = ContaAzulClient(
        client_id=cfg["client_id"],
        client_secret=cfg["client_secret"],
        tokens=tokens,
        on_token_refresh=store.save_tokens,  # persiste a cada renovação
    )

    # -------- janela
    janela = args.dias if args.dias is not None else cfg["janela_dias"]
    hoje = date.today()
    # buscar um pouco para frente também, para pegar vencimentos futuros
    data_de  = hoje - timedelta(days=janela)
    data_ate = hoje + timedelta(days=janela)
    logger.info("Janela de sincronização: %s → %s", data_de, data_ate)

    # -------- ingestão (staging)
    logger.info("=== STAGING ===")
    _safe_ingest("categorias",           store, lambda: ingest_categorias(client, store))
    _safe_ingest("centros_custo",        store, lambda: ingest_centros_custo(client, store))
    _safe_ingest("contas_financeiras",   store, lambda: ingest_contas_financeiras(client, store))
    _safe_ingest("contas_pagar",         store, lambda: ingest_contas_pagar(client, store, data_de, data_ate))
    _safe_ingest("contas_receber",       store, lambda: ingest_contas_receber(client, store, data_de, data_ate))
    _safe_ingest("vendas",               store, lambda: ingest_vendas(client, store, data_de, data_ate))

    # -------- refresh marts
    logger.info("=== MART ===")
    logger.info("  dim_categoria         → %d linhas afetadas", store.refresh_dim_categoria())
    logger.info("  dim_centro_custo      → %d linhas afetadas", store.refresh_dim_centro_custo())
    logger.info("  dim_conta_financeira  → %d linhas afetadas", store.refresh_dim_conta_financeira())
    logger.info("  fato_parcela          → %d linhas afetadas", store.refresh_fato_parcela())
    logger.info("  fato_venda            → %d linhas afetadas", store.refresh_fato_venda())

    logger.info("ETL concluído.")


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        logger.exception("Falha fatal no ETL: %s", e)
        sys.exit(1)
