"""
Autenticação OAuth 2.0 com a API ContaAzul (nova plataforma, api-v2).

Fluxo Authorization Code:
  1) Primeira execução: abre navegador → usuário autoriza → captura code via
     servidor HTTP local efêmero → troca por access_token + refresh_token →
     grava na tabela staging_contaazul.oauth_tokens.
  2) Próximas execuções: lê tokens da tabela; se access_token expirou,
     renova usando refresh_token.

Docs de referência:
  https://developers.contaazul.com/auth
  https://developers.contaazul.com/faq

Base64(client_id:client_secret) no header Authorization (Basic).
"""
from __future__ import annotations

import base64
import logging
import secrets
import threading
import time
import urllib.parse
import webbrowser
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Optional

import requests

logger = logging.getLogger(__name__)

AUTH_BASE_URL = "https://auth.contaazul.com"
AUTHORIZE_URL = f"{AUTH_BASE_URL}/oauth2/authorize"
TOKEN_URL = f"{AUTH_BASE_URL}/oauth2/token"


@dataclass
class TokenSet:
    access_token: str
    refresh_token: str
    expires_at: datetime  # timezone-aware (UTC)

    def expired(self, skew_seconds: int = 60) -> bool:
        return datetime.now(timezone.utc) >= (self.expires_at - timedelta(seconds=skew_seconds))


class _CallbackHandler(BaseHTTPRequestHandler):
    """Handler efêmero que captura o ?code= do redirect."""

    received_code: Optional[str] = None
    received_state: Optional[str] = None

    def do_GET(self):  # noqa: N802
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path != "/callback":
            self.send_response(404)
            self.end_headers()
            return
        qs = urllib.parse.parse_qs(parsed.query)
        _CallbackHandler.received_code = qs.get("code", [None])[0]
        _CallbackHandler.received_state = qs.get("state", [None])[0]
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()
        self.wfile.write(
            "<html><body style='font-family:sans-serif;padding:40px'>"
            "<h2>✅ Autorização recebida</h2>"
            "<p>Pode fechar esta aba e voltar para o terminal.</p>"
            "</body></html>".encode("utf-8")
        )

    def log_message(self, *_args):
        # silencia log do servidor http
        pass


def _basic_auth_header(client_id: str, client_secret: str) -> str:
    token = base64.b64encode(f"{client_id}:{client_secret}".encode("utf-8")).decode("ascii")
    return f"Basic {token}"


def _exchange_code_for_tokens(
    client_id: str,
    client_secret: str,
    redirect_uri: str,
    code: str,
) -> TokenSet:
    resp = requests.post(
        TOKEN_URL,
        headers={
            "Authorization": _basic_auth_header(client_id, client_secret),
            "Content-Type": "application/x-www-form-urlencoded",
        },
        data={
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": redirect_uri,
        },
        timeout=30,
    )
    resp.raise_for_status()
    payload = resp.json()
    return TokenSet(
        access_token=payload["access_token"],
        refresh_token=payload["refresh_token"],
        expires_at=datetime.now(timezone.utc) + timedelta(seconds=int(payload.get("expires_in", 3600))),
    )


def refresh_tokens(client_id: str, client_secret: str, refresh_token: str) -> TokenSet:
    """Renova access_token usando refresh_token."""
    resp = requests.post(
        TOKEN_URL,
        headers={
            "Authorization": _basic_auth_header(client_id, client_secret),
            "Content-Type": "application/x-www-form-urlencoded",
        },
        data={
            "grant_type": "refresh_token",
            "refresh_token": refresh_token,
        },
        timeout=30,
    )
    resp.raise_for_status()
    payload = resp.json()
    # Nem todo provedor devolve refresh_token novo; manter o antigo se não vier
    new_refresh = payload.get("refresh_token", refresh_token)
    return TokenSet(
        access_token=payload["access_token"],
        refresh_token=new_refresh,
        expires_at=datetime.now(timezone.utc) + timedelta(seconds=int(payload.get("expires_in", 3600))),
    )


def interactive_authorize(
    client_id: str,
    client_secret: str,
    redirect_uri: str,
    scopes: str = "sales",
    callback_port: int = 8765,
) -> TokenSet:
    """
    Abre navegador, captura o code via servidor HTTP local e retorna TokenSet.
    Deve ser rodado UMA VEZ para bootstrap. Depois o refresh_token cuida sozinho.
    """
    state = secrets.token_urlsafe(24)
    params = {
        "response_type": "code",
        "client_id": client_id,
        "redirect_uri": redirect_uri,
        "scope": scopes,
        "state": state,
    }
    url = f"{AUTHORIZE_URL}?{urllib.parse.urlencode(params)}"

    server = HTTPServer(("127.0.0.1", callback_port), _CallbackHandler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()

    logger.info("Abrindo navegador para autorização ContaAzul...")
    webbrowser.open(url)

    # aguarda até 5 minutos pela autorização
    deadline = time.time() + 300
    while time.time() < deadline and _CallbackHandler.received_code is None:
        time.sleep(0.5)

    server.shutdown()

    if _CallbackHandler.received_code is None:
        raise TimeoutError("Tempo esgotado aguardando autorização do usuário.")
    if _CallbackHandler.received_state != state:
        raise ValueError("Parâmetro 'state' divergente: possível ataque CSRF.")

    code = _CallbackHandler.received_code
    logger.info("Código capturado, trocando por tokens...")
    return _exchange_code_for_tokens(client_id, client_secret, redirect_uri, code)
