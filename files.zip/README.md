# ContaAzul → PostgreSQL (ETL de referência)

ETL de referência para extrair dados financeiros e de vendas da API **ContaAzul v2** (`api-v2.contaazul.com/v1`) e gravar em um PostgreSQL com **camada staging (JSONB)** e **mart modelado para BI** (Power BI, Excel, dashboards HTML).

Endpoints cobertos: categorias, centros de custo, contas financeiras, contas a pagar/receber com suas parcelas, e vendas.

## 1. Pré-requisitos

- Python 3.10+
- PostgreSQL 13+
- Aplicação criada no [Portal do Desenvolvedor ContaAzul](https://developers-portal.contaazul.com) (gera `client_id` + `client_secret`)
- Na aplicação, cadastrar a **Redirect URI**: `http://localhost:8765/callback`

## 2. Instalação

```bash
pip install -r requirements.txt
psql -h $PG_HOST -U $PG_USER -d $PG_DATABASE -f schema.sql
cp .env.example .env   # e preencha as credenciais
```

## 3. Primeira execução (bootstrap OAuth)

```bash
python etl.py --bootstrap
```

O script abre o navegador, você autoriza, o `authorization_code` é capturado em um servidor HTTP local efêmero, trocado por `access_token + refresh_token` e gravado na tabela `staging_contaazul.oauth_tokens`. Deve ser feito **uma única vez** por empresa integrada.

## 4. Execuções periódicas

```bash
python etl.py                 # janela padrão definida no .env
python etl.py --dias 90       # últimos e próximos 90 dias
python etl.py --full          # força janela ampla (ETL_JANELA_DIAS)
```

Exemplo de agendamento (cron, a cada 4 horas):
```
0 */4 * * * cd /opt/contaazul_etl && /usr/bin/python etl.py >> /var/log/contaazul_etl.log 2>&1
```

## 5. Arquitetura

```
ContaAzul API (api-v2.contaazul.com)
         │
         ▼
   [etl.py]  ──►  staging_contaazul.*   (JSONB bruto + id)
         │               │
         │               ▼
         └──────►  mart_contaazul.*     (dim_* / fato_* prontos para BI)
```

**Por que JSONB na staging?** A API do ContaAzul ainda evolui (sem SDK oficial, sem webhooks). Guardar o payload cru torna a reprocessamento de novos campos trivial — basta ajustar o SQL do mart sem re-baixar dados.

## 6. Modelo do mart (grão e relacionamentos)

| Tabela | Grão | Uso em BI |
|---|---|---|
| `dim_categoria` | Uma linha por categoria | Dimensão de plano de contas |
| `dim_centro_custo` | Uma linha por centro | Dimensão para rateio |
| `dim_conta_financeira` | Uma linha por conta | Dimensão de banco/caixa |
| `fato_parcela` | **Uma linha por parcela** | Fluxo de caixa previsto x realizado, aging, DRE |
| `fato_venda` | Uma linha por venda | Faturamento, ticket médio |

O grão correto para fluxo de caixa é **parcela**, não o evento financeiro — por isso `fato_parcela` existe como tabela principal.

## 7. Pontos de atenção

- **Rate limit**: a API aplica limite por aplicação. O cliente já faz backoff exponencial em 429/5xx.
- **Renovação de token**: automática a cada chamada (com 60s de folga antes do expiry). Cada renovação é persistida no banco.
- **Endpoint de vendas**: a nova plataforma está consolidando o caminho — o script tenta `/venda` e faz fallback para `/vendas`. Valide com sua aplicação e ajuste se necessário.
- **Paginação**: padrão `pagina`/`tamanho_pagina`. O cliente identifica a chave da lista automaticamente (`itens`, `items`, `data`, `content`, `resultados`).
- **Sem webhook**: a ContaAzul ainda não oferece webhooks — o ETL é puramente pull/polling.

## 8. Arquivos

```
contaazul_etl/
├── .env.example          # template de configuração
├── requirements.txt
├── schema.sql            # DDL do Postgres (staging + mart)
├── contaazul_auth.py     # OAuth 2.0 (authorize + refresh)
├── contaazul_client.py   # Cliente HTTP com retry e paginação
├── postgres_store.py     # UPSERTs staging + refresh marts
└── etl.py                # Orquestrador principal
```

## 9. Exemplo de consultas para dashboards

**Contas a receber em atraso por cliente (top 20):**
```sql
SELECT
    id_contato,
    SUM(valor_nao_pago)  AS valor_em_atraso,
    COUNT(*)             AS qtd_parcelas
FROM mart_contaazul.fato_parcela
WHERE tipo_evento = 'RECEBER'
  AND status     IN ('ATRASADO', 'PENDENTE')
  AND data_vencimento < CURRENT_DATE
GROUP BY id_contato
ORDER BY valor_em_atraso DESC
LIMIT 20;
```

**Previsão de caixa nos próximos 30 dias:**
```sql
SELECT
    data_vencimento,
    SUM(CASE WHEN tipo_evento='RECEBER' THEN valor_original ELSE 0 END) AS entradas,
    SUM(CASE WHEN tipo_evento='PAGAR'   THEN valor_original ELSE 0 END) AS saidas
FROM mart_contaazul.fato_parcela
WHERE status IN ('PENDENTE','ATRASADO')
  AND data_vencimento BETWEEN CURRENT_DATE AND CURRENT_DATE + 30
GROUP BY data_vencimento
ORDER BY data_vencimento;
```

**DRE simplificado do mês por categoria:**
```sql
SELECT
    c.nome            AS categoria,
    c.tipo            AS tipo,
    SUM(p.valor_pago) AS total_realizado
FROM mart_contaazul.fato_parcela p
JOIN mart_contaazul.dim_categoria c ON c.id_categoria = p.id_categoria
WHERE p.status = 'QUITADO'
  AND date_trunc('month', p.data_pagamento_previsto) = date_trunc('month', CURRENT_DATE)
GROUP BY c.nome, c.tipo
ORDER BY c.tipo, total_realizado DESC;
```
