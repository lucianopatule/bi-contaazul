"""
Cliente da API ContaAzul (api-v2).

Responsabilidades:
  - Injetar Bearer token em toda chamada
  - Renovar token automaticamente quando expira
  - Paginação (pagina / tamanho_pagina) até esgotar
  - Retry com backoff exponencial em 429/5xx
  - Respeitar limites (a API tem rate limit por aplicação)

Base URL documentada: https://api-v2.contaazul.com/v1
"""
from __future__ import annotations

import logging
from typing import Any, Callable, Dict, Iterator, Optional

import requests
from tenacity import (
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

from contaazul_auth import TokenSet, refresh_tokens

logger = logging.getLogger(__name__)

API_BASE = "https://api-v2.contaazul.com/v1"


class ContaAzulAPIError(Exception):
    pass


class ContaAzulClient:
    def __init__(
        self,
        client_id: str,
        client_secret: str,
        tokens: TokenSet,
        on_token_refresh: Optional[Callable[[TokenSet], None]] = None,
    ):
        self.client_id = client_id
        self.client_secret = client_secret
        self.tokens = tokens
        # callback para persistir tokens renovados (ex: gravar no Postgres)
        self.on_token_refresh = on_token_refresh
        self.session = requests.Session()

    # ------------------------------------------------------------------ tokens
    def _ensure_fresh_token(self) -> None:
        if self.tokens.expired():
            logger.info("Access token expirado, renovando via refresh_token...")
            self.tokens = refresh_tokens(
                self.client_id, self.client_secret, self.tokens.refresh_token
            )
            if self.on_token_refresh:
                self.on_token_refresh(self.tokens)

    # ------------------------------------------------------------------ request
    @retry(
        reraise=True,
        stop=stop_after_attempt(5),
        wait=wait_exponential(multiplier=1, min=2, max=30),
        retry=retry_if_exception_type((requests.ConnectionError, requests.Timeout, ContaAzulAPIError)),
    )
    def _request(self, method: str, path: str, **kwargs) -> Any:
        self._ensure_fresh_token()
        url = f"{API_BASE}{path}" if path.startswith("/") else f"{API_BASE}/{path}"
        headers = kwargs.pop("headers", {})
        headers["Authorization"] = f"Bearer {self.tokens.access_token}"
        headers.setdefault("Accept", "application/json")

        resp = self.session.request(method, url, headers=headers, timeout=60, **kwargs)

        # 401: token pode ter sido invalidado antes de expires_in; força refresh e tenta de novo
        if resp.status_code == 401:
            logger.warning("401 recebido — forçando refresh de token")
            self.tokens = refresh_tokens(
                self.client_id, self.client_secret, self.tokens.refresh_token
            )
            if self.on_token_refresh:
                self.on_token_refresh(self.tokens)
            headers["Authorization"] = f"Bearer {self.tokens.access_token}"
            resp = self.session.request(method, url, headers=headers, timeout=60, **kwargs)

        # 429 / 5xx → deixa tenacity re-tentar via exceção
        if resp.status_code == 429 or 500 <= resp.status_code < 600:
            raise ContaAzulAPIError(
                f"{resp.status_code} em {method} {path}: {resp.text[:300]}"
            )

        if not resp.ok:
            raise ContaAzulAPIError(
                f"{resp.status_code} em {method} {path}: {resp.text[:500]}"
            )

        if resp.status_code == 204 or not resp.content:
            return None
        return resp.json()

    # ------------------------------------------------------------------ public
    def get(self, path: str, params: Optional[Dict[str, Any]] = None) -> Any:
        return self._request("GET", path, params=params)

    def paginate(
        self,
        path: str,
        params: Optional[Dict[str, Any]] = None,
        page_size: int = 100,
        items_key_candidates: tuple = ("itens", "items", "data", "content", "resultados"),
    ) -> Iterator[Dict[str, Any]]:
        """
        Itera todas as páginas do endpoint. A API ContaAzul v2 usa os parâmetros
        'pagina' e 'tamanho_pagina'. A chave da lista varia por endpoint, então
        tentamos vários nomes comuns. Caso a resposta seja lista pura, itera direto.
        """
        params = dict(params or {})
        params.setdefault("tamanho_pagina", page_size)
        page = 1
        while True:
            params["pagina"] = page
            payload = self.get(path, params=params)

            if payload is None:
                return

            # resposta pode ser lista direta
            if isinstance(payload, list):
                if not payload:
                    return
                yield from payload
                if len(payload) < page_size:
                    return
                page += 1
                continue

            # resposta é dict com items embaixo de alguma chave
            items = None
            for key in items_key_candidates:
                if key in payload and isinstance(payload[key], list):
                    items = payload[key]
                    break
            if items is None:
                # sem lista reconhecível → trata o próprio payload como registro único
                yield payload
                return

            if not items:
                return

            yield from items

            # critérios de parada: menos que o tamanho de página OU
            # campos de paginação explícitos (total_paginas etc.)
            total_paginas = payload.get("total_paginas") or payload.get("totalPages")
            if total_paginas and page >= int(total_paginas):
                return
            if len(items) < page_size:
                return
            page += 1
