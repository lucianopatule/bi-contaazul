-- =====================================================================
-- SCHEMA CONTAAZUL → POSTGRESQL PARA BI
-- =====================================================================
-- Arquitetura em 2 camadas:
--   staging_contaazul  → dados brutos (JSONB) + chaves de negócio
--   mart_contaazul     → tabelas normalizadas/modeladas para BI
--
-- Padrão adotado:
--   - Todas as PKs usam UUID (mesmo padrão do ContaAzul)
--   - Campo payload JSONB preserva o payload original para auditoria
--     e para campos novos que surgirem sem quebrar o ETL
--   - Colunas de controle: loaded_at, updated_at_api
-- =====================================================================

CREATE SCHEMA IF NOT EXISTS staging_contaazul;
CREATE SCHEMA IF NOT EXISTS mart_contaazul;

-- =====================================================================
-- CONTROLE DE SINCRONIZAÇÃO
-- =====================================================================
CREATE TABLE IF NOT EXISTS staging_contaazul.sync_control (
    endpoint           TEXT PRIMARY KEY,
    last_sync_at       TIMESTAMPTZ,
    last_success_at    TIMESTAMPTZ,
    last_status        TEXT,
    last_error         TEXT,
    records_last_run   INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS staging_contaazul.oauth_tokens (
    id                 SMALLINT PRIMARY KEY DEFAULT 1,
    access_token       TEXT NOT NULL,
    refresh_token      TEXT NOT NULL,
    expires_at         TIMESTAMPTZ NOT NULL,
    updated_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT single_row CHECK (id = 1)
);

-- =====================================================================
-- STAGING: uma tabela por endpoint, carga bruta em JSONB
-- =====================================================================

-- Categorias financeiras (plano de contas)
CREATE TABLE IF NOT EXISTS staging_contaazul.raw_categorias (
    id              UUID PRIMARY KEY,
    payload         JSONB NOT NULL,
    loaded_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Centros de custo
CREATE TABLE IF NOT EXISTS staging_contaazul.raw_centros_custo (
    id              UUID PRIMARY KEY,
    payload         JSONB NOT NULL,
    loaded_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Contas financeiras (bancos, caixinhas, cartões)
CREATE TABLE IF NOT EXISTS staging_contaazul.raw_contas_financeiras (
    id              UUID PRIMARY KEY,
    payload         JSONB NOT NULL,
    loaded_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Eventos financeiros: contas a pagar
CREATE TABLE IF NOT EXISTS staging_contaazul.raw_contas_pagar (
    id              UUID PRIMARY KEY,
    payload         JSONB NOT NULL,
    loaded_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Eventos financeiros: contas a receber
CREATE TABLE IF NOT EXISTS staging_contaazul.raw_contas_receber (
    id              UUID PRIMARY KEY,
    payload         JSONB NOT NULL,
    loaded_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Parcelas (granularidade de fluxo de caixa)
CREATE TABLE IF NOT EXISTS staging_contaazul.raw_parcelas (
    id              UUID PRIMARY KEY,
    id_evento       UUID NOT NULL,
    tipo_evento     TEXT NOT NULL,  -- 'PAGAR' ou 'RECEBER'
    payload         JSONB NOT NULL,
    loaded_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_raw_parcelas_evento ON staging_contaazul.raw_parcelas (id_evento);

-- Vendas
CREATE TABLE IF NOT EXISTS staging_contaazul.raw_vendas (
    id              UUID PRIMARY KEY,
    payload         JSONB NOT NULL,
    loaded_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- =====================================================================
-- MART: dimensões e fatos prontos para Power BI / Excel
-- =====================================================================

CREATE TABLE IF NOT EXISTS mart_contaazul.dim_categoria (
    id_categoria        UUID PRIMARY KEY,
    codigo              TEXT,
    nome                TEXT,
    tipo                TEXT,          -- RECEITA / DESPESA
    id_categoria_pai    UUID,
    ativo               BOOLEAN,
    atualizado_em       TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS mart_contaazul.dim_centro_custo (
    id_centro_custo     UUID PRIMARY KEY,
    codigo              TEXT,
    nome                TEXT,
    ativo               BOOLEAN,
    atualizado_em       TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS mart_contaazul.dim_conta_financeira (
    id_conta            UUID PRIMARY KEY,
    nome                TEXT,
    tipo                TEXT,          -- CONTA_CORRENTE, CARTAO_CREDITO, etc.
    ativo               BOOLEAN,
    atualizado_em       TIMESTAMPTZ DEFAULT NOW()
);

-- Fato de parcelas = grão correto para fluxo de caixa previsto x realizado
CREATE TABLE IF NOT EXISTS mart_contaazul.fato_parcela (
    id_parcela              UUID PRIMARY KEY,
    id_evento               UUID NOT NULL,
    tipo_evento             TEXT NOT NULL,   -- PAGAR / RECEBER
    indice_parcela          INTEGER,
    status                  TEXT,            -- PENDENTE, QUITADO, ATRASADO, CANCELADO
    data_vencimento         DATE,
    data_pagamento_previsto DATE,
    data_competencia        DATE,
    valor_original          NUMERIC(18,2),
    valor_pago              NUMERIC(18,2),
    valor_nao_pago          NUMERIC(18,2),
    id_conta_financeira     UUID,
    id_categoria            UUID,
    id_centro_custo         UUID,
    id_contato              UUID,            -- cliente/fornecedor
    descricao               TEXT,
    forma_pagamento         TEXT,
    atualizado_em           TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_fato_parcela_venc   ON mart_contaazul.fato_parcela (data_vencimento);
CREATE INDEX IF NOT EXISTS idx_fato_parcela_status ON mart_contaazul.fato_parcela (status);
CREATE INDEX IF NOT EXISTS idx_fato_parcela_tipo   ON mart_contaazul.fato_parcela (tipo_evento);
CREATE INDEX IF NOT EXISTS idx_fato_parcela_cat    ON mart_contaazul.fato_parcela (id_categoria);

-- Fato de vendas
CREATE TABLE IF NOT EXISTS mart_contaazul.fato_venda (
    id_venda            UUID PRIMARY KEY,
    numero_venda        TEXT,
    data_venda          DATE,
    status              TEXT,
    id_cliente          UUID,
    valor_total         NUMERIC(18,2),
    valor_desconto      NUMERIC(18,2),
    observacao          TEXT,
    atualizado_em       TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_fato_venda_data ON mart_contaazul.fato_venda (data_venda);
